import matplotlib.pyplot as plt
import matplotlib.image as mpimg

from aof.skeleton.2D import compute_2D_aof
from distance.transform import get_distance_transform

from utils import rgb2gray


def get_aof_skeleton(img_path):
    img = mpimg.imread(img_path)

    if len(img.shape) == 3:
        img = rgb2gray(img) 

    # Show gray scale img
    # plt.imshow(img, cmap=plt.get_cmap('gray'), vmin=0, vmax=1)
    # plt.show()

    dist_img, idx = get_distance_transform(img)
    plt.imshow(dist_img)
    plt.show()

    compute_2D_aof()

img_path = "data/city_1.png"
get_aof_skeleton(img_path=img_path)

print('Program Ended ....')