Medial Axis implementation of AOF Skeletonization
